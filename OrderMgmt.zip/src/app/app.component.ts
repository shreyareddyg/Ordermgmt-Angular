import { Component, OnInit } from '@angular/core';
import { MyserviceService } from './myservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = "angular-nav-dropdown-toggle";

  activeUser: any;
  users: any[] = [];
  unselectedUsers: any[] = [];
  constructor(private _myservice: MyserviceService) { }
  ngOnInit() {
    this._myservice.getCustomers().subscribe(response => {
      response.forEach((i) => {
        this.users.push(i);
      });
    //  if(!localStorage.getItem("activeUser")){
        this.activeUser = this.users[0];
      localStorage.setItem("activeUser", this.activeUser.userId);
      console.log(localStorage.getItem("activeUser"));
      this.users
        .filter((i) => i.userId != this.activeUser.userId)
        .forEach((i) => {
          this.unselectedUsers.push(i);
        });
      console.log(response);
   //   }
      /*else{
        this.activeUser=localStorage.getItem("activeUser");
      }*/
    });
      }
      

  //  this.users = [];
  selectedUser(selectedUser) {
    localStorage.setItem("activeUser", selectedUser.userId);
    this.activeUser = selectedUser;
    this.unselectedUsers = [];
    //removing selected user from the list as the selected user should not show in the list
    this.unselectedUsers = this.users.filter((i) => i.userId != this.activeUser.userId);
   
    //on select if we wnat to navigate/redirect to somewhere(component name or path will be avilable in routing.module.ts)
    // this.router.navigate['/{componentName}']
  }




}

