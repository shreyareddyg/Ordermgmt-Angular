import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private httpService: HttpClient) { }

  public getList() {
    console.log("ins service get list");
    return this.httpService.get<Product[]>("http://localhost:6565/products/GetList");
  }

  public getProduct(id : number) {
    console.log("ins service get Product");
    return this.httpService.get<Product>("http://localhost:6565/products/GetProduct/"+id);
  }

   public addItemToCart(productid: String, userId: String) {
    console.log("ins service get item");
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json' });
  let options = { headers: headers };
 //   let options = { headers:{ 'Content-Type': 'application/json'}  } 
    var cart: Cart = new Cart(userId,productid,1);
    var response = this.httpService.post<string>("http://localhost:6500/api/v1/orders/addtocart", JSON.stringify(cart),options);
  console.log(response);
  return response;
	}

  public  getProducts(userId: String) {
    console.log("ins service get products");
		return this.httpService.get<Cart[]>("http://localhost:6500/api/v1/orders/cart/products/" + userId);
	}

  public createOrder(userId: String){
    console.log("ins service created order");
    let options = { headers:{ 'Content-Type': 'application/json'}  } 
    var order: Order = new Order(userId,"46-152",'');
    var response = this.httpService.post<string>("http://localhost:6500/api/v1/orders/createOrder", JSON.stringify(order), options);
  console.log(response);
  return response;
	}
  
	 public  getAllOrders() {
    console.log("ins service get orders");
		return this.httpService.get<Order[]>("http://localhost:6500/api/v1/orders/all");
	}

  
	public removeProductFromCart( productId: String, userId: String) {
		// This returns a JSON or XML with the user
		const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:6500/api/v1/orders/" + userId + "/" +productId,  { headers, responseType: 'text'});
	}


	public  removeOrder(orderId : String) {
		// This returns a JSON or XML with the user
console.log("delete order")
const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:6500/api/v1/orders/" + orderId,  { headers, responseType: 'text'});
	}


  public  getCustomers() {
    console.log("ins service get products");
		return this.httpService.get<User[]>("http://localhost:6500/api/v1/orders/users");
	}



}

export class Product {
   productid: String;
	 productUin: String;
  productispresent: boolean;

  constructor(productid: String,productUin: String, productispresent: boolean)
{
  this.productUin=productUin;
  this.productid=productid;
  this.productispresent=productispresent;
}

}
export class Cart{
  userId: String;
  productId: String;
  quantity: number;

constructor(userId: String,productId: String, quantity: number)
{
  this.userId=userId;
  this.productId=productId;
  this.quantity=quantity;
}
}
export class Order{
  userId: String;
  addressId: String;
  orderId: String;

constructor(userId: String,addressId: String, orderId: String)
{
  this.userId=userId;
  this.addressId=addressId;
  this.orderId=orderId;
}



}
export class User{
  userId: String;
  username: String;

  constructor(userId: String,username: String)
{
  this.userId=userId;
  this.username=username;

}
}